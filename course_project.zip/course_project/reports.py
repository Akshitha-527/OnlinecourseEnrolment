from db_config import get_connection
from tabulate import tabulate

def student_report():
    try:
        conn = get_connection()
        if not conn:
            return
        cursor = conn.cursor()

        cursor.execute("""
        SELECT u.name, c.course_name, AVG(p.completion_percentage)
        FROM users u
        JOIN enrollments e ON u.user_id=e.user_id
        JOIN courses c ON e.course_id=c.course_id
        JOIN progress p ON e.enrollment_id=p.enrollment_id
        GROUP BY u.name, c.course_name
        """)

        data = cursor.fetchall()
        print(tabulate(data, headers=["Student","Course","Progress %"]))
    except Exception as e:
        print(f"❌ Error generating student report: {e}")
    finally:
        if 'conn' in locals() and conn:
            conn.close()

def course_report():
    try:
        conn = get_connection()
        if not conn:
            return
        cursor = conn.cursor()

        cursor.execute("""
        SELECT c.course_name, COUNT(e.enrollment_id), AVG(p.completion_percentage)
        FROM courses c
        LEFT JOIN enrollments e ON c.course_id=e.course_id
        LEFT JOIN progress p ON e.enrollment_id=p.enrollment_id
        GROUP BY c.course_name
        """)

        data = cursor.fetchall()
        print(tabulate(data, headers=["Course","Enrollments","Avg Progress %"]))
    except Exception as e:
        print(f"❌ Error generating course report: {e}")
    finally:
        if 'conn' in locals() and conn:
            conn.close()
