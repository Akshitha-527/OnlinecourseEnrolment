import bcrypt
from db_config import get_connection

def register_user(name, email, password, role):
    conn = get_connection()
    cur = conn.cursor()
    try:
        hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
        # Normalize role to ENUM values
        role_norm = str(role).capitalize()
        if role_norm not in ("Student", "Instructor", "Admin"):
            raise ValueError("Invalid role. Use Student, Instructor, or Admin.")

        cur.execute(
            "INSERT INTO users(name,email,password_hash,role) VALUES(%s,%s,%s,%s)",
            (name, email, hashed.decode(), role_norm)
        )
        conn.commit()
        print("✅ User Registered Successfully")
    except Exception as e:
        print(f"❌ Registration failed: {e}")
    finally:
        cur.close()
        conn.close()


def login_user(email, password):
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute("SELECT user_id, password_hash, role FROM users WHERE email = %s AND status = 'Active'", (email,))
        user = cur.fetchone()
        if user and bcrypt.checkpw(password.encode(), user[1].encode()):
            return user[0], user[2]
        print("❌ Invalid credentials or inactive user")
        return None, None
    finally:
        cur.close()
        conn.close()
